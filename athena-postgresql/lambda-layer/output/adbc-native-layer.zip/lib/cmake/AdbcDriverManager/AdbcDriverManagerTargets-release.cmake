#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "AdbcDriverManager::adbc_driver_manager_shared" for configuration "Release"
set_property(TARGET AdbcDriverManager::adbc_driver_manager_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(AdbcDriverManager::adbc_driver_manager_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libadbc_driver_manager.so.108.0.0"
  IMPORTED_SONAME_RELEASE "libadbc_driver_manager.so.108"
  )

list(APPEND _IMPORT_CHECK_TARGETS AdbcDriverManager::adbc_driver_manager_shared )
list(APPEND _IMPORT_CHECK_FILES_FOR_AdbcDriverManager::adbc_driver_manager_shared "${_IMPORT_PREFIX}/lib64/libadbc_driver_manager.so.108.0.0" )

# Import target "AdbcDriverManager::adbc_driver_manager_static" for configuration "Release"
set_property(TARGET AdbcDriverManager::adbc_driver_manager_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(AdbcDriverManager::adbc_driver_manager_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libadbc_driver_manager.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS AdbcDriverManager::adbc_driver_manager_static )
list(APPEND _IMPORT_CHECK_FILES_FOR_AdbcDriverManager::adbc_driver_manager_static "${_IMPORT_PREFIX}/lib64/libadbc_driver_manager.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
